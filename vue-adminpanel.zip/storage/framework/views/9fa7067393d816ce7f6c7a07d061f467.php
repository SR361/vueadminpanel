
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Admin | Login</title>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/login.css', 'resources/js/app.js']); ?>
    </head>
    <body class="hold-transition login-page">
        <div class="login-box" id="app">
            <router-view></router-view>
        </div>
    </body>
</html>
<?php /**PATH D:\xampp\htdocs\vue-adminpanel\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>