<?php

namespace App\Enums;

enum RoleType: int
{
    case ADMINS = 1;
    case USER = 2;
}
